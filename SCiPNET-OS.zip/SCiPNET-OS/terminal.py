"""
SCiPNET — Terminal v1.0
App standalone — nécessite une session active (session.dat)
"""
import sys, os, random, threading, urllib.request
from pathlib import Path
from datetime import datetime

from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QLabel,
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QColor, QTextCursor

# Ajouter le dossier de l'app au path
sys.path.insert(0, "/opt/scipnet")
from scipnet_common import (
    BG, BG2, BG3, WIN_BG, BORDER, BORDER_B,
    WHITE, DIM, DARK, CYAN, CYAN_D, RED, YELLOW, GREEN,
    MONO, NIVEAU_LABELS, NIVEAU_COLORS,
    F, S, DataStore, ScipnetWindow, check_clearance, load_barlow,
)

# ══════════════════════════════════════════════════════════════════════════════
#  DONNÉES SITE (partagées)
# ══════════════════════════════════════════════════════════════════════════════
_SCP_API = "https://scp-data.tedivm.com/data/scp/items/index.json"
_SCP_INDEX: dict = {}
SITE_NAME = "AYIN"
ETAT_COLORS = {
    "NOMINAL":"#22bb44","ALERTE":"#f5d020",
    "RISQUE ÉLEVÉ":"#ff8800","CONFINEMENT":"#cc3333","ÉVACUATION":"#cc00ff",
}

def _load_site_data():
    cfg = DataStore.load("config.dat", {})
    global SITE_NAME
    if cfg.get("site_name"): SITE_NAME = cfg["site_name"]
    return cfg.get("personnel", [
        {"id":"sec","nom":"Sécurité",      "effectif":42,"max":60, "etat":"NOMINAL"},
        {"id":"sci","nom":"Recherche",     "effectif":31,"max":40, "etat":"NOMINAL"},
        {"id":"med","nom":"Médical",       "effectif":14,"max":20, "etat":"NOMINAL"},
        {"id":"eng","nom":"Génie",         "effectif":18,"max":25, "etat":"NOMINAL"},
        {"id":"adm","nom":"Administration","effectif": 8,"max":12, "etat":"NOMINAL"},
        {"id":"dcl","nom":"Classe-D",      "effectif":23,"max":50, "etat":"NOMINAL"},
    ])

def _get_scp(number: str, callback):
    def _run():
        key = f"scp-{number}"
        candidates = [key, f"scp-{int(number):03d}" if number.isdigit() else None,
                      f"scp-{int(number)}" if number.isdigit() else None]
        if _SCP_INDEX:
            for c in candidates:
                if c and c in _SCP_INDEX:
                    callback(_SCP_INDEX[c], None); return
            callback(None, f"SCP-{number} introuvable"); return
        try:
            with urllib.request.urlopen(_SCP_API, timeout=8) as r:
                data = r.read().decode()
            import json; idx = json.loads(data)
            for c in candidates:
                if c and c in idx:
                    callback(idx[c], None); return
            callback(None, f"SCP-{number} introuvable")
        except Exception as e:
            callback(None, str(e))
    threading.Thread(target=_run, daemon=True).start()

# ══════════════════════════════════════════════════════════════════════════════
#  TERMINAL WIDGET
# ══════════════════════════════════════════════════════════════════════════════
class TerminalWidget(QWidget):
    def __init__(self, login: str, niveau: int, nom_affiche: str = "", parent=None):
        super().__init__(parent)
        self.login        = login
        self.niveau       = niveau
        self.nom_affiche  = nom_affiche or login
        self.history = []
        self.hidx    = -1
        self._last_url = None
        self._personnel = _load_site_data()
        self._aliases   = self._load_aliases()
        self._build()
        self._boot()

    def _load_aliases(self) -> dict:
        """Charge les commandes personnalisées depuis config."""
        cfg = DataStore.load("terminal_config.dat", {})
        return cfg.get("aliases", {})

    def _save_aliases(self):
        cfg = DataStore.load("terminal_config.dat", {})
        cfg["aliases"] = self._aliases
        DataStore.save("terminal_config.dat", cfg)

    def _build(self):
        self.setStyleSheet(f"background:{WIN_BG};")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # Zone de sortie
        self.out = QTextEdit()
        self.out.setReadOnly(True)
        self.out.setStyleSheet(
            f"background:{WIN_BG};color:{WHITE};font-family:'{MONO}';"
            f"font-size:11px;border:none;padding:14px;"
            f"selection-background-color:{CYAN_D};"
        )
        self.out.setFont(F(11))
        lay.addWidget(self.out, 1)

        # Barre de saisie
        bar = QWidget()
        bar.setFixedHeight(38)
        bar.setStyleSheet(f"background:{BG2};border-top:1px solid {BORDER};")
        bh = QHBoxLayout(bar)
        bh.setContentsMargins(14, 0, 14, 0)
        bh.setSpacing(0)

        self.prompt = QLabel(f"{self.login}@scipnet:~$ ")
        # Nom affiché dans whoami
        self.prompt.setStyleSheet(
            f"color:{GREEN};font-family:'{MONO}';font-size:11px;background:{BG2};"
        )

        self.inp = QLineEdit()
        self.inp.setStyleSheet(
            f"QLineEdit{{background:{BG2};color:{WHITE};font-family:'{MONO}';"
            f"font-size:11px;border:none;padding:0 4px;"
            f"selection-background-color:{CYAN_D};selection-color:{WHITE};}}"
        )
        pal = self.inp.palette()
        pal.setColor(pal.ColorRole.Text,   QColor(WHITE))
        pal.setColor(pal.ColorRole.Base,   QColor(BG2))
        pal.setColor(pal.ColorRole.Window, QColor(BG2))
        self.inp.setPalette(pal)
        self.inp.setFont(F(11))
        self.inp.returnPressed.connect(self._exec)
        self.inp.installEventFilter(self)

        bh.addWidget(self.prompt)
        bh.addWidget(self.inp, 1)
        lay.addWidget(bar)

    def showEvent(self, e):
        super().showEvent(e)
        self.inp.setFocus()

    def _p(self, html: str):
        self.out.append(html)
        self.out.moveCursor(QTextCursor.MoveOperation.End)

    def _boot(self):
        now = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
        sep = f"<span style='color:{BORDER_B};'>{'─'*48}</span>"
        lines = [
            (sep, 0),
            (f"<span style='color:{CYAN};font-size:13px;font-weight:600;letter-spacing:3px;'>"
             f"{'─'*4} SCiPNET TERMINAL v4.1.6 {'─'*4}</span>", 40),
            (f"<span style='color:{DIM};letter-spacing:2px;'>Secure, Contain, Protect</span>", 90),
            (f"<span style='color:{DARK};'>SCP Foundation Database Network</span>", 130),
            (f"<span style='color:{DARK};'>Access time : {now}</span>", 170),
            (sep, 210),
            (f"<span style='color:{DIM};'>Opérateur  : <b style='color:{WHITE};'>{self.nom_affiche}</b>"
             f"  │  Clairance : <b style='color:{NIVEAU_COLORS.get(self.niveau,CYAN)};'>N{self.niveau} — "
             f"{NIVEAU_LABELS.get(self.niveau,'?')}</b></span>", 260),
            (f"<span style='color:{DARK};'>Session    : ████-{random.randint(1000,9999)}</span>", 300),
            (sep, 340),
            (f"<span style='color:{DIM};'>Tapez <b style='color:{WHITE};'>help</b> pour la liste des commandes.</span>", 380),
            ("", 420),
        ]
        for html, ms in lines:
            QTimer.singleShot(ms, lambda h=html: self._p(h))
        QTimer.singleShot(460, lambda: self.inp.setFocus())

    def _exec(self):
        cmd = self.inp.text().strip()
        self.inp.clear(); self.inp.setFocus()
        if not cmd: return
        self.history.insert(0, cmd); self.hidx = -1
        self._p(f"<span style='color:{GREEN}'>{self.login}@scipnet:~$</span>"
                f" <span style='color:{WHITE}'>{cmd}</span>")
        self._cmd(cmd)

    def _cmd(self, cmd: str):
        parts = cmd.strip().split()
        c = parts[0].lower() if parts else ""

        # ── Résolution des alias ──────────────────────────────────────────────
        if c in self._aliases:
            expanded = self._aliases[c]
            # Remplacer $1, $2... par les arguments
            for i, arg in enumerate(parts[1:], 1):
                expanded = expanded.replace(f"${i}", arg)
            self._p(f"<span style='color:{DARK}'>→ {expanded}</span>")
            self._cmd(expanded)
            return

        if c == "help":
            self._p(f"<span style='color:{DIM}'>─── COMMANDES ───</span>")
            for n, d in [
                ("help",        "Cette aide"),
                ("clear",       "Vider le terminal"),
                ("whoami",      "Informations session"),
                ("ls",          "Lister les archives"),
                ("scp [n°]",    "Fiche SCP (ex: scp 173)"),
                ("open",        "Ouvrir lien SCP dans navigateur"),
                (f"status",     f"État du Site-{SITE_NAME}"),
                ("logout",      "Fermer le terminal"),
                ("alias n=cmd",  "Créer un raccourci (ex: alias s=status)"),
                ("unalias n",    "Supprimer un raccourci"),
                ("aliases",      "Lister les raccourcis"),
            ]:
                self._p(f"  <span style='color:{CYAN}'>{n:<22}</span>"
                        f"<span style='color:{DIM}'>{d}</span>")

        elif c == "clear":
            self.out.clear()

        elif c == "whoami":
            self._p(
                f"<span style='color:{DIM}'>Identité : <b style='color:{WHITE}'>{self.nom_affiche}</b>"
                f"  |  Clairance : <b style='color:{NIVEAU_COLORS.get(self.niveau,CYAN)}'>"
                f"N{self.niveau} — {NIVEAU_LABELS.get(self.niveau,'?')}</b></span>"
            )

        elif c == "ls":
            rows = [
                (1, "SCP-████/ [SAFE]"),
                (2, "SCP-████/ [EUCLIDE]"),
                (3, "SCP-████/ [KETER]"),
                (4, "O5-DIR/   [SECRET]"),
            ]
            for req, name in rows:
                if req <= self.niveau:
                    self._p(f"  <span style='color:{WHITE}'>{name}</span>")
                else:
                    self._p(f"  <span style='color:{DARK}'>██████/ [ACCÈS REFUSÉ]</span>")

        elif c == "status":
            total    = sum(d.get("effectif", 0) for d in self._personnel)
            max_tot  = sum(d.get("max", 0) for d in self._personnel)
            etats    = [d.get("etat", "NOMINAL") for d in self._personnel]
            priority = ["ÉVACUATION","CONFINEMENT","RISQUE ÉLEVÉ","ALERTE","NOMINAL"]
            getat    = next((e for e in priority if e in etats), "NOMINAL")
            gcol     = ETAT_COLORS.get(getat, GREEN)

            self._p(f"<span style='color:{DIM}'>─── SITE-{SITE_NAME} STATUS ───</span>")
            self._p(f"  <span style='color:{gcol}'>■</span>"
                    f" <span style='color:{DIM}'>État global : <b style='color:{gcol}'>{getat}</b></span>")
            self._p(f"  <span style='color:{GREEN}'>■</span>"
                    f" <span style='color:{DIM}'>Personnel actif : <b style='color:{WHITE}'>{total}</b> / {max_tot}</span>")
            for d in self._personnel:
                ec = ETAT_COLORS.get(d.get("etat", "NOMINAL"), DIM)
                self._p(f"    <span style='color:{DARK}'>·</span>"
                        f" <span style='color:{ec}'>{d.get('nom','?'):<20}</span>"
                        f"<span style='color:{DIM}'>{d.get('effectif',0)}/{d.get('max',0)}</span>")
            self._p(f"  <span style='color:{DIM}'>■</span>"
                    f" <span style='color:{DIM}'>Hume index : <b style='color:{WHITE}'>1.000</b></span>")

        elif c == "scp":
            num = parts[1] if len(parts) > 1 else None
            if not num or not num.isdigit():
                self._p(f"<span style='color:{RED}'>Usage : scp [numéro]  ex: scp 173</span>")
            else:
                self._p(f"<span style='color:{DIM}'>Interrogation archive"
                        f" <b style='color:{WHITE}'>SCP-{num}</b>…</span>")
                def _cb(data, err, n=num):
                    if err or not data:
                        self._p(f"<span style='color:{RED}'>SCP-{n} : {err or 'introuvable'}</span>")
                        return
                    title  = data.get("title", "?")
                    rating = data.get("rating", "?")
                    tags   = data.get("tags", [])
                    cls    = next((t.upper() for t in tags if t.lower() in
                                   ["safe","euclid","keter","thaumiel","neutralized","apollyon"]), "?")
                    url    = data.get("url", "")
                    self._p(f"<span style='color:{CYAN}'>{data.get('scp','SCP-'+n)}</span>"
                            f"  <span style='color:{WHITE}'>{title}</span>")
                    self._p(f"  <span style='color:{DIM}'>Classe : <b style='color:{WHITE}'>{cls}</b>"
                            f"  |  Rating : <b style='color:{YELLOW}'>+{rating}</b></span>")
                    if url:
                        self._p(f"  <span style='color:{CYAN}'>{url}</span>")
                        self._last_url = url
                        self._p(f"  <span style='color:{DIM}'>Tapez <b style='color:{WHITE}'>open</b>"
                                f" pour ouvrir dans le navigateur.</span>")
                _get_scp(num, lambda d, e, cb=_cb: QTimer.singleShot(0, lambda: cb(d, e)))

        elif c == "open":
            if self._last_url:
                import webbrowser
                webbrowser.open(self._last_url)
                self._p(f"<span style='color:{GREEN}'>Ouverture : {self._last_url}</span>")
            else:
                self._p(f"<span style='color:{RED}'>Aucun lien — utilisez d'abord 'scp [n°]'</span>")

        elif c == "logout":
            self._p(f"<span style='color:{DIM}'>Fermeture du terminal…</span>")
            QTimer.singleShot(600, lambda: self.window().close())

        elif c == "aliases":
            if not self._aliases:
                self._p(f"<span style='color:{DIM}'>Aucun alias défini. Utilisez : alias nom=commande</span>")
            else:
                self._p(f"<span style='color:{DIM}'>─── ALIAS DÉFINIS ───</span>")
                for name, cmd_val in sorted(self._aliases.items()):
                    self._p(f"  <span style='color:{CYAN}'>{name:<16}</span>"
                            f"<span style='color:{DIM}'>→ {cmd_val}</span>")

        elif c == "alias":
            # Format : alias nom=commande
            rest = " ".join(parts[1:])
            if "=" not in rest:
                self._p(f"<span style='color:{RED}'>Usage : alias nom=commande  ex: alias s=status</span>")
            else:
                name, _, val = rest.partition("=")
                name = name.strip().lower()
                val  = val.strip()
                if not name or not val:
                    self._p(f"<span style='color:{RED}'>Nom et commande requis.</span>")
                elif name in ("help","clear","whoami","ls","scp","open","status",
                              "logout","alias","unalias","aliases"):
                    self._p(f"<span style='color:{RED}'>'{name}' est une commande native — choisissez un autre nom.</span>")
                else:
                    self._aliases[name] = val
                    self._save_aliases()
                    self._p(f"<span style='color:{GREEN}'>Alias créé : "
                            f"<b style='color:{WHITE}'>{name}</b>"
                            f" → <b style='color:{CYAN}'>{val}</b></span>")

        elif c == "unalias":
            name = parts[1].lower() if len(parts) > 1 else ""
            if not name:
                self._p(f"<span style='color:{RED}'>Usage : unalias nom</span>")
            elif name in self._aliases:
                del self._aliases[name]
                self._save_aliases()
                self._p(f"<span style='color:{YELLOW}'>Alias '{name}' supprimé.</span>")
            else:
                self._p(f"<span style='color:{RED}'>Alias '{name}' introuvable.</span>")

        else:
            self._p(f"<span style='color:{RED}'>Commande inconnue : {cmd}</span>")

    def eventFilter(self, obj, event):
        from PyQt6.QtCore import QEvent
        if obj is self.inp and event.type() == QEvent.Type.KeyPress:
            k = event.key()
            if k == Qt.Key.Key_Up and self.history:
                self.hidx = min(self.hidx + 1, len(self.history) - 1)
                self.inp.setText(self.history[self.hidx]); return True
            elif k == Qt.Key.Key_Down:
                self.hidx = max(self.hidx - 1, -1)
                self.inp.setText(self.history[self.hidx] if self.hidx >= 0 else "")
                return True
        return super().eventFilter(obj, event)

# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════
def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    load_barlow()

    # Vérification clairance
    login, niveau, nom_affiche = check_clearance("Terminal")

    win = ScipnetWindow("Terminal", login, niveau, nom_affiche, width=900, height=580)
    terminal = TerminalWidget(login, niveau, nom_affiche)
    win.set_content(terminal)
    win.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
