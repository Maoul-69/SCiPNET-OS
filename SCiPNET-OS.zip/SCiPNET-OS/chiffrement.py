"""
SCiPNET — Chiffrement v1.0
App standalone — nécessite une session active (session.dat)
"""
import sys, json
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QLabel, QPushButton, QFileDialog,
    QListWidget, QListWidgetItem, QSplitter, QFrame,
    QDialog, QDialogButtonBox, QComboBox, QMenu, QCheckBox,
    QScrollArea,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor

sys.path.insert(0, "/opt/scipnet")
from scipnet_common import (
    BG, BG2, BG3, WIN_BG, BORDER, BORDER_B,
    WHITE, DIM, DARK, CYAN, CYAN_D, RED, YELLOW, GREEN,
    MONO, NIVEAU_LABELS, NIVEAU_COLORS,
    F, S, DataStore, ScipnetWindow, check_clearance, load_barlow,
)

try:
    from cryptography.fernet import Fernet
    HAS_FERNET = True
except ImportError:
    HAS_FERNET = False

EXT = ".scpenc"
TEXT_EXTS = {".txt",".md",".log",".csv",".json",".xml",".html",".htm",".ini",".cfg",".py",".js"}


class CryptoWidget(QWidget):
    def __init__(self, login: str, niveau: int, nom_affiche: str = "", parent=None):
        super().__init__(parent)
        self.login        = login
        self.niveau       = niveau
        self._nom_affiche = nom_affiche
        self._cur_file: Path | None = None
        self._is_encrypted = False
        self._nom_affiche = nom_affiche
        self._build()
        self._enc_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self._enc_list.customContextMenuRequested.connect(self._enc_list_menu)

    def _is_text(self, path: Path) -> bool:
        name = path.name
        if name.endswith(EXT): name = name[:-len(EXT)]
        return Path(name).suffix.lower() in TEXT_EXTS

    def _build(self):
        self.setStyleSheet(f"background:{WIN_BG};")
        root = QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)

        sp = QSplitter(Qt.Orientation.Horizontal)
        sp.setStyleSheet(f"QSplitter::handle{{background:{BORDER};width:1px;}}")

        # ── Panneau gauche ────────────────────────────────────────────────────
        left = QWidget(); lv = QVBoxLayout(left); lv.setContentsMargins(0,0,0,0); lv.setSpacing(0)

        # Boutons d'action
        act = QWidget(); act.setFixedHeight(50)
        act.setStyleSheet(f"background:{BG2};border-bottom:1px solid {BORDER};")
        ah = QHBoxLayout(act); ah.setContentsMargins(12,0,12,0); ah.setSpacing(8)

        def mk_btn(txt, col, cb):
            b = QPushButton(txt)
            b.setStyleSheet(
                f"QPushButton{{background:{BG3};color:{col};font-family:'{MONO}';"
                f"font-size:9px;letter-spacing:2px;padding:6px 12px;"
                f"border:1px solid {BORDER_B};}}"
                f"QPushButton:hover{{background:{col};color:{BG};}}"
                f"QPushButton:disabled{{color:{DARK};border-color:{BORDER};}}"
            )
            b.clicked.connect(cb); return b

        self._open_btn  = mk_btn("📂 OUVRIR",    CYAN,      self._pick_file)
        self._enc_btn   = mk_btn("🔒 CHIFFRER",  "#aa44ff", self._encrypt)
        self._dec_btn   = mk_btn("🔓 DÉCHIFFRER",GREEN,     self._decrypt)
        self._lock_btn  = mk_btn("⊗ ACCÈS",      RED,       self._open_lock_dialog)
        self._scan_btn  = mk_btn("🔍 SCANNER",   YELLOW,    self._scan_folder)
        self._enc_btn.setEnabled(False)
        self._dec_btn.setEnabled(False)
        self._lock_btn.setEnabled(False)
        for b in [self._open_btn, self._enc_btn, self._dec_btn, self._lock_btn, self._scan_btn]:
            ah.addWidget(b)
        ah.addStretch(); lv.addWidget(act)

        # Liste fichiers chiffrés
        lv.addWidget(QLabel("  FICHIERS CHIFFRÉS",
            styleSheet=f"color:{DARK};font-family:'{MONO}';font-size:8px;letter-spacing:3px;"
                       f"padding:8px 12px 4px;background:{BG2};"))
        self._enc_list = QListWidget()
        self._enc_list.setStyleSheet(
            f"QListWidget{{background:{BG2};color:{WHITE};font-family:'{MONO}';"
            f"font-size:10px;border:none;padding:4px;}}"
            f"QListWidget::item{{padding:4px 10px;border-bottom:1px solid {BORDER};}}"
            f"QListWidget::item:selected{{background:{BORDER_B};}}"
        )
        self._enc_list.setFont(F(10))
        self._enc_list.itemDoubleClicked.connect(self._list_open)
        lv.addWidget(self._enc_list, 1); sp.addWidget(left)

        # ── Panneau droit ─────────────────────────────────────────────────────
        right = QWidget(); rv = QVBoxLayout(right); rv.setContentsMargins(0,0,0,0); rv.setSpacing(0)

        hdr = QWidget(); hdr.setFixedHeight(40)
        hdr.setStyleSheet(f"background:{BG3};border-bottom:1px solid {BORDER};")
        hh = QHBoxLayout(hdr); hh.setContentsMargins(14,0,14,0); hh.setSpacing(8)
        self._editor_title = QLabel("— AUCUN FICHIER —")
        self._editor_title.setStyleSheet(S(DIM,9,bold=True,ls=2))
        hh.addWidget(self._editor_title, 1)
        self._save_btn = mk_btn("💾 ENREGISTRER", CYAN, self._save)
        self._save_btn.setEnabled(False)
        hh.addWidget(self._save_btn); rv.addWidget(hdr)

        self._status_lbl = QLabel()
        self._status_lbl.setStyleSheet(S(DIM,9,ls=0))
        self._status_lbl.setContentsMargins(14,6,14,6)
        rv.addWidget(self._status_lbl)

        self._path_lbl = QLabel("—")
        self._path_lbl.setStyleSheet(S(DARK,8,ls=0))
        self._path_lbl.setContentsMargins(14,0,14,6)
        rv.addWidget(self._path_lbl)

        self._editor = QTextEdit()
        self._editor.setStyleSheet(
            f"background:{WIN_BG};color:{WHITE};font-family:'{MONO}';"
            f"font-size:11px;border:none;padding:14px;"
        )
        self._editor.setFont(F(11)); rv.addWidget(self._editor, 1)

        # Log
        self._log = QTextEdit(); self._log.setReadOnly(True)
        self._log.setFixedHeight(80)
        self._log.setStyleSheet(
            f"background:{BG2};color:{DIM};font-family:'{MONO}';"
            f"font-size:9px;border:none;border-top:1px solid {BORDER};padding:6px;"
        )
        rv.addWidget(self._log); sp.addWidget(right)
        sp.setSizes([280, 620]); root.addWidget(sp, 1)

        if not HAS_FERNET:
            self._log_msg("cryptography non installé — pip install cryptography", RED)

    def _log_msg(self, msg: str, col=DIM):
        from datetime import datetime
        t = datetime.now().strftime("%H:%M:%S")
        self._log.append(f"<span style='color:{DARK};'>[{t}]</span> <span style='color:{col};'>{msg}</span>")

    def _pick_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Ouvrir fichier", str(Path.home()))
        if path: self._load_file(Path(path))

    def _list_open(self, it):
        path = Path(it.data(Qt.ItemDataRole.UserRole))
        if path.exists(): self._load_file(path)

    def _load_file(self, path: Path):
        self._cur_file = path
        self._path_lbl.setText(str(path))
        fname  = path.name
        is_enc = path.suffix.lower() == EXT
        is_txt = self._is_text(path)
        self._is_encrypted = is_enc

        if is_enc:
            self._status_lbl.setText(f"🔒 CHIFFRÉ  —  {fname}")
            self._status_lbl.setStyleSheet(S("#aa44ff",9,ls=0))
            self._enc_btn.setEnabled(False); self._dec_btn.setEnabled(True)
            self._lock_btn.setEnabled(True)
            ok, text = self._decrypt_to_text(path)
            if not ok:
                self._editor.setPlainText(f"[ERREUR]\n{text}")
                self._editor.setReadOnly(True); self._save_btn.setEnabled(False)
            elif text is None:
                ext = Path(fname[:-len(EXT)]).suffix.upper()
                self._editor.setPlainText(
                    f"Fichier binaire {ext} chiffré.\n\n"
                    f"Cliquez sur 🔓 DÉCHIFFRER pour restaurer sur le disque."
                )
                self._editor.setReadOnly(True); self._save_btn.setEnabled(False)
            else:
                self._editor.setPlainText(text)
                self._editor.setReadOnly(False); self._save_btn.setEnabled(True)
                self._editor_title.setText(fname + "  [déchiffré en mémoire]")
        else:
            self._status_lbl.setText(f"🔓 NON CHIFFRÉ  —  {fname}")
            self._status_lbl.setStyleSheet(S(GREEN,9,ls=0))
            self._enc_btn.setEnabled(HAS_FERNET); self._dec_btn.setEnabled(False)
            self._lock_btn.setEnabled(False)
            if is_txt:
                self._editor.setPlainText(self._read_text(path))
                self._editor.setReadOnly(False); self._save_btn.setEnabled(True)
            else:
                ext = path.suffix.upper()
                self._editor.setPlainText(f"Fichier binaire {ext}.\n\nCliquez sur 🔒 CHIFFRER pour le chiffrer.")
                self._editor.setReadOnly(True); self._save_btn.setEnabled(False)
            self._editor_title.setText(fname)
        self._log_msg(f"Fichier chargé : {fname}", DIM)

    def _read_text(self, path: Path) -> str:
        for enc in ("utf-8","utf-8-sig","latin-1","cp1252"):
            try: return path.read_text(encoding=enc)
            except: continue
        return path.read_bytes().decode("utf-8", errors="replace")

    def _decrypt_to_text(self, path: Path) -> tuple[bool, str | None]:
        if not HAS_FERNET: return False, "cryptography non installé"
        try:
            cipher = DataStore._cipher()
            dec = cipher.decrypt(path.read_bytes())
            if not self._is_text(path): return True, None
            for enc in ("utf-8","utf-8-sig","latin-1","cp1252"):
                try: return True, dec.decode(enc)
                except: continue
            return True, dec.decode("utf-8", errors="replace")
        except Exception as e:
            return False, str(e)

    def _encrypt(self):
        if not self._cur_file or not HAS_FERNET: return
        try:
            cipher = DataStore._cipher()
            raw = self._cur_file.read_bytes()
            out = self._cur_file.with_suffix(self._cur_file.suffix + EXT)
            out.write_bytes(cipher.encrypt(raw))
            self._cur_file.unlink()
            self._log_msg(f"Chiffré → {out.name}", "#aa44ff")
            self._load_file(out); self._scan_folder()
        except Exception as e:
            self._log_msg(f"Erreur chiffrement : {e}", RED)

    def _decrypt(self):
        if not self._cur_file or not HAS_FERNET: return
        # Vérifier les restrictions d'accès
        lock = self._load_lock(self._cur_file)
        ok, reason = self._check_lock(lock)
        if not ok:
            self._log_msg(f"ACCÈS REFUSÉ : {reason}", RED)
            self._editor.setHtml(
                f"<div style='font-family:{MONO};font-size:12px;padding:20px;'>"  
                f"<span style='color:{RED};font-size:18px;font-weight:600;'>⊗  DÉCHIFFREMENT REFUSÉ</span><br><br>"
                f"<span style='color:{DIM};'>{reason}</span></div>"
            )
            return
        try:
            out = Path(str(self._cur_file)[:-len(EXT)])
            cipher = DataStore._cipher()
            decrypted = cipher.decrypt(self._cur_file.read_bytes())
            out.write_bytes(decrypted)
            self._cur_file.unlink()
            # Supprimer le fichier lock associé
            lock_f = self._lock_path(self._cur_file)
            if lock_f.exists(): lock_f.unlink()
            self._log_msg(f"Déchiffré → {out.name}", GREEN)
            self._load_file(out); self._scan_folder()
        except Exception as e:
            self._log_msg(f"Erreur déchiffrement : {e}", RED)

    def _save(self):
        if not self._cur_file or not self._is_text(self._cur_file): return
        text = self._editor.toPlainText()
        try:
            if self._is_encrypted:
                cipher = DataStore._cipher()
                self._cur_file.write_bytes(cipher.encrypt(text.encode("utf-8")))
                self._log_msg(f"Sauvegardé (chiffré) : {self._cur_file.name}", "#aa44ff")
            else:
                self._cur_file.write_text(text, encoding="utf-8")
                self._log_msg(f"Sauvegardé : {self._cur_file.name}", GREEN)
        except Exception as e:
            self._log_msg(f"Erreur sauvegarde : {e}", RED)

    def _lock_path(self, path: Path) -> Path:
        return path.parent / (path.name + ".access")

    def _load_lock(self, path: Path) -> dict:
        lp = self._lock_path(path)
        if not lp.exists(): return {}
        try:
            raw = lp.read_bytes()
            c = DataStore._cipher()
            if c:
                try: raw = c.decrypt(raw)
                except: pass
            return json.loads(raw.decode("utf-8"))
        except: return {}

    def _save_lock(self, path: Path, lock: dict):
        lp = self._lock_path(path)
        if not lock:
            if lp.exists(): lp.unlink()
            return
        raw = json.dumps(lock, ensure_ascii=False).encode("utf-8")
        c = DataStore._cipher()
        lp.write_bytes(c.encrypt(raw) if c else raw)

    def _check_lock(self, lock: dict) -> tuple[bool, str]:
        """Vérifie si l'utilisateur courant peut déchiffrer. Retourne (ok, raison)."""
        if not lock: return True, ""
        niv_min = lock.get("niveau_min", 0)
        logins  = lock.get("logins_autorises", [])
        note    = lock.get("note_refus", "Accès non autorisé.")

        # Si des logins spécifiques sont définis
        if logins:
            if self.login.lower() in [l.lower() for l in logins]:
                return True, ""
            return False, note + f"\nCompte autorisé(s) : {', '.join(logins)}"

        # Sinon vérifier le niveau
        if niv_min > 0 and self.niveau < niv_min:
            return False, (note + f"\nNiveau requis : N{niv_min} — {NIVEAU_LABELS.get(niv_min,'?')}"
                          f"\nVotre niveau  : N{self.niveau}")

        return True, ""

    def _open_lock_dialog(self):
        """Ouvre le dialog de configuration des restrictions."""
        if not self._cur_file or not self._is_encrypted: return
        lock = self._load_lock(self._cur_file)
        # Charger la liste des utilisateurs pour l'autocomplétion
        users = DataStore.load("users.dat", {})
        dlg  = LockDialog(lock, self.login, self.niveau, users, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            new_lock = dlg.get_lock()
            self._save_lock(self._cur_file, new_lock)
            if new_lock:
                niv = new_lock.get("niveau_min", 0)
                logins = new_lock.get("logins_autorises", [])
                parts = []
                if niv: parts.append(f"N{niv}+")
                if logins: parts.append(", ".join(logins))
                self._log_msg(
                    f"Restrictions appliquées : {' | '.join(parts) or 'aucune'}",
                    RED
                )
            else:
                self._log_msg("Restrictions supprimées.", DIM)

    def _enc_list_menu(self, pos):
        """Menu contextuel sur la liste des fichiers chiffrés."""
        it = self._enc_list.itemAt(pos)
        if not it: return
        path = Path(it.data(Qt.ItemDataRole.UserRole))
        if not path.exists(): return

        lock = self._load_lock(path)
        has_lock = bool(lock)

        menu = QMenu(self)
        menu.setStyleSheet(
            f"QMenu{{background:{BG2};color:{WHITE};font-family:'{MONO}';font-size:10px;"
            f"border:1px solid {BORDER_B};}}"
            f"QMenu::item{{padding:6px 20px;}}"
            f"QMenu::item:selected{{background:{BORDER_B};}}"
        )
        open_act  = menu.addAction("📂  Ouvrir")
        menu.addSeparator()
        lock_act  = menu.addAction(
            f"⊗  {'Modifier les restrictions' if has_lock else 'Restreindre l\'accès'}"
        )
        if has_lock:
            clear_act = menu.addAction("⊘  Supprimer les restrictions")
        menu.addSeparator()
        info_act  = menu.addAction(
            f"ℹ  {'Restrictions actives' if has_lock else 'Aucune restriction'}"
        )
        info_act.setEnabled(False)

        action = menu.exec(self._enc_list.viewport().mapToGlobal(pos))
        if action == open_act:
            self._load_file(path)
        elif action == lock_act:
            self._cur_file = path
            self._is_encrypted = True
            self._open_lock_dialog()
        elif has_lock and action == clear_act:
            self._save_lock(path, {})
            self._log_msg(f"Restrictions supprimées : {path.name}", DIM)

    def _scan_folder(self):
        folder = self._cur_file.parent if self._cur_file else Path.home()
        self._enc_list.clear()
        found = sorted(folder.rglob(f"*{EXT}"))
        for f in found:
            it = QListWidgetItem(f"🔒  {f.name}")
            it.setData(Qt.ItemDataRole.UserRole, str(f))
            it.setForeground(QColor("#aa44ff"))
            self._enc_list.addItem(it)
        if not found:
            it = QListWidgetItem("Aucun fichier chiffré trouvé")
            it.setForeground(QColor(DARK)); self._enc_list.addItem(it)


# ── Chemin du fichier lock ────────────────────────────────────────────────────
def _lock_file_for(path: Path) -> Path:
    return path.parent / (path.name + ".access")

class LockDialog(QDialog):
    """Dialog de configuration des restrictions d'accès sur un fichier chiffré."""
    def __init__(self, lock: dict, login: str, niveau: int, users: dict = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("SCiPNET — Restrictions d'accès")
        self.setMinimumWidth(460)
        self.setStyleSheet(f"background:{BG2};color:{WHITE};font-family:'{MONO}';")
        self._lock  = dict(lock)
        self._users = users or {}

        v = QVBoxLayout(self); v.setSpacing(10); v.setContentsMargins(20,20,20,20)
        v.addWidget(QLabel("RESTRICTIONS DE DÉCHIFFREMENT",
            styleSheet=S(RED,11,bold=True,ls=3)))
        v.addWidget(QLabel(
            "Définissez qui peut déchiffrer ce fichier.",
            styleSheet=S(DIM,9,ls=0)
        ))

        sep = QFrame(); sep.setFixedHeight(1)
        sep.setStyleSheet(f"background:{BORDER};"); v.addWidget(sep)

        def inp_style():
            return (f"QLineEdit{{background:{BG3};color:{WHITE};font-family:'{MONO}';"
                    f"font-size:10px;border:1px solid {BORDER_B};padding:5px 8px;}}"
                    f"QLineEdit:focus{{border:1px solid {CYAN};}}")
        def cb_style():
            return (f"QComboBox{{background:{BG3};color:{WHITE};font-family:'{MONO}';"
                    f"font-size:10px;border:1px solid {BORDER_B};padding:5px 8px;}}"
                    f"QComboBox QAbstractItemView{{background:{BG2};color:{WHITE};"
                    f"border:1px solid {BORDER};selection-background-color:{CYAN_D};}}")

        def row(lbl, widget, hint=""):
            rw = QWidget(); rw.setStyleSheet("background:transparent;")
            rv = QVBoxLayout(rw); rv.setContentsMargins(0,0,0,0); rv.setSpacing(3)
            rv.addWidget(QLabel(lbl, styleSheet=S(DIM,8,bold=True,ls=2)))
            rv.addWidget(widget)
            if hint: rv.addWidget(QLabel(hint, styleSheet=S(DARK,8,ls=0)))
            return rw

        # ── Niveau minimum ────────────────────────────────────────────────────
        self._niv_combo = QComboBox(); self._niv_combo.setStyleSheet(cb_style())
        self._niv_combo.addItem("Aucune restriction (N1+)", userData=0)
        for n, lbl in NIVEAU_LABELS.items():
            self._niv_combo.addItem(f"N{n} minimum — {lbl}", userData=n)
        cur_niv = lock.get("niveau_min", 0)
        for i in range(self._niv_combo.count()):
            if self._niv_combo.itemData(i) == cur_niv:
                self._niv_combo.setCurrentIndex(i); break
        v.addWidget(row("NIVEAU MINIMUM REQUIS", self._niv_combo))

        # ── Logins autorisés ──────────────────────────────────────────────────
        from PyQt6.QtWidgets import QLineEdit
        # Liste des utilisateurs avec cases à cocher
        logins_autorises = lock.get("logins_autorises", [])
        users_w = QWidget(); users_w.setStyleSheet(f"background:{BG3};border:1px solid {BORDER_B};")
        users_v = QVBoxLayout(users_w); users_v.setContentsMargins(8,8,8,8); users_v.setSpacing(4)
        self._login_checks = {}

        if self._users:
            for ulogin, udata in sorted(self._users.items()):
                nom    = udata.get("nom", "")
                titre  = udata.get("titre", "")
                niveau = udata.get("niveau", 1)
                ncol   = NIVEAU_COLORS.get(niveau, DIM)
                label  = f"{titre} {nom}".strip() if (titre or nom) else ulogin
                cb = QCheckBox(f"  {ulogin:<18}  {label}")
                cb.setChecked(ulogin in logins_autorises)
                cb.setStyleSheet(
                    f"QCheckBox{{color:{WHITE};font-family:'{MONO}';font-size:10px;background:transparent;}}"
                    f"QCheckBox::indicator{{width:14px;height:14px;border:1px solid {BORDER_B};background:{BG2};}}"
                    f"QCheckBox::indicator:checked{{background:{CYAN};border:1px solid {CYAN};}}"
                )
                cb.toggled.connect(self._update_preview)
                users_v.addWidget(cb)
                self._login_checks[ulogin] = cb
        else:
            users_v.addWidget(QLabel(
                "Aucun utilisateur trouvé dans users.dat",
                styleSheet=S(DARK,9,ls=0)
            ))

        rl = QWidget(); rl.setStyleSheet("background:transparent;")
        rlv = QVBoxLayout(rl); rlv.setContentsMargins(0,0,0,0); rlv.setSpacing(3)
        rlv.addWidget(QLabel("COMPTES AUTORISÉS", styleSheet=S(DIM,8,bold=True,ls=2)))
        rlv.addWidget(QLabel(
            "Cochez les comptes autorisés à déchiffrer. Si aucun coché → niveau minimum seul.",
            styleSheet=S(DARK,8,ls=0)
        ))
        rlv.addWidget(users_w)
        v.addWidget(rl)

        # ── Note affichée en cas de refus ─────────────────────────────────────
        from PyQt6.QtWidgets import QTextEdit as _QTE
        self._note_inp = _QTE()
        self._note_inp.setFixedHeight(70)
        self._note_inp.setPlainText(lock.get("note_refus",
            "Accès non autorisé. Contactez l'administrateur du site."))
        self._note_inp.setStyleSheet(
            f"QTextEdit{{background:{BG3};color:{WHITE};font-family:'{MONO}';"
            f"font-size:10px;border:1px solid {BORDER_B};padding:5px;}}"
        )
        v.addWidget(row("MESSAGE EN CAS DE REFUS", self._note_inp))

        # ── Aperçu ────────────────────────────────────────────────────────────
        self._preview = QLabel()
        self._preview.setWordWrap(True)
        self._preview.setStyleSheet(
            f"background:{BG3};color:{DIM};font-family:'{MONO}';"
            f"font-size:8px;padding:8px;border:1px solid {BORDER};"
        )
        self._niv_combo.currentIndexChanged.connect(self._update_preview)
        self._update_preview()
        v.addWidget(self._preview)

        # ── Bouton supprimer les restrictions ─────────────────────────────────
        clear_btn = QPushButton("⊘  SUPPRIMER TOUTES LES RESTRICTIONS")
        clear_btn.setStyleSheet(
            f"QPushButton{{background:transparent;color:{DARK};font-family:'{MONO}';"
            f"font-size:8px;letter-spacing:2px;padding:5px;border:none;}}"
            f"QPushButton:hover{{color:{RED};}}"
        )
        clear_btn.clicked.connect(self._clear)
        v.addWidget(clear_btn)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel
        )
        btns.button(QDialogButtonBox.StandardButton.Ok).setText("APPLIQUER →")
        btns.setStyleSheet(
            f"QPushButton{{background:{BG3};color:{CYAN};font-family:'{MONO}';"
            f"font-size:9px;letter-spacing:2px;padding:6px 16px;border:1px solid {BORDER_B};}}"
            f"QPushButton:hover{{background:{CYAN};color:{BG};}}"
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        v.addWidget(btns)

    def _update_preview(self):
        niv    = self._niv_combo.currentData() or 0
        logins = [u for u, cb in self._login_checks.items() if cb.isChecked()]
        parts  = []
        if niv > 0:
            parts.append(f"Niveau minimum : N{niv} — {NIVEAU_LABELS.get(niv,'?')}")
        if logins:
            labels = []
            for u in logins:
                ud = self._users.get(u, {})
                nom = ud.get("nom",""); titre = ud.get("titre","")
                label = f"{titre} {nom}".strip() if (titre or nom) else u
                labels.append(f"{u} ({label})")
            parts.append(f"Comptes : {', '.join(labels)}")
        if not parts:
            self._preview.setText("Aucune restriction — tout le monde peut déchiffrer.")
        else:
            self._preview.setText("Restrictions actives :\n" + "\n".join(f"  · {p}" for p in parts))

    def _clear(self):
        self._niv_combo.setCurrentIndex(0)
        for cb in self._login_checks.values():
            cb.setChecked(False)

    def get_lock(self) -> dict:
        niv    = self._niv_combo.currentData() or 0
        logins = [u for u, cb in self._login_checks.items() if cb.isChecked()]
        note   = self._note_inp.toPlainText().strip()
        if niv == 0 and not logins:
            return {}
        return {
            "niveau_min"      : niv,
            "logins_autorises": logins,
            "note_refus"      : note or "Accès non autorisé.",
        }


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    load_barlow()
    login, niveau, nom_affiche = check_clearance("Chiffrement")
    win = ScipnetWindow("Chiffrement", login, niveau, nom_affiche, width=950, height=620)
    widget = CryptoWidget(login, niveau, nom_affiche)
    win.set_content(widget)
    win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
